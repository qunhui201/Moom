#!/bin/bash
echo "===== SYSTEM INFO ====="
uname -a
cat /etc/os-release
echo

echo "===== CPU INFO ====="
lscpu | grep -E 'Model name|CPU\(s\)|Thread|Core'
echo

echo "===== MEMORY ====="
free -h
echo

echo "===== DISK ====="
df -h
echo

echo "===== NETWORK ====="
hostname -I 2>/dev/null || echo "No IP info available"
echo "Public IP: $(curl -s ifconfig.me)"
echo

echo "===== GPU ====="
command -v nvidia-smi &>/dev/null && nvidia-smi || echo "No NVIDIA GPU detected"
echo

echo "===== USER INFO ====="
whoami
id
echo
