#!/usr/bin/env python3
import http.server
import ssl
import os

# 配置
DIRECTORY = "/home/user/app"  # 需要提供下载的目录
PORT = 8443  # HTTPS 端口

# 自动切换到目标目录
os.chdir(DIRECTORY)

# 创建 HTTP 请求处理器
Handler = http.server.SimpleHTTPRequestHandler

# 启动 HTTPServer
httpd = http.server.HTTPServer(('0.0.0.0', PORT), Handler)

# 自签名证书路径
CERT_FILE = os.path.join(DIRECTORY, "selfsigned.pem")
KEY_FILE = os.path.join(DIRECTORY, "selfsigned.key")

# 如果证书不存在，生成自签名证书
if not os.path.exists(CERT_FILE) or not os.path.exists(KEY_FILE):
    print("生成自签名证书...")
    os.system(f"openssl req -new -x509 -days 365 -nodes -out {CERT_FILE} -keyout {KEY_FILE} -subj '/CN=localhost'")

# 包装成 HTTPS
httpd.socket = ssl.wrap_socket(httpd.socket,
                               server_side=True,
                               certfile=CERT_FILE,
                               keyfile=KEY_FILE,
                               ssl_version=ssl.PROTOCOL_TLS)

print(f"Serving HTTPS on 0.0.0.0 port {PORT} (https://IP:{PORT}/) ...")
httpd.serve_forever()
