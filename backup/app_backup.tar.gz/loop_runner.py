#!/usr/bin/env python3
import time
import subprocess

# ---------- 配置 ----------
SCRIPT = "/home/user/app/tests.py"  # 你的 Python 脚本路径
INTERVAL = 1800                    # 间隔秒数，比如 1800 秒 = 30 分钟
# ---------------------------

while True:
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Running {SCRIPT} ...")
    # 执行脚本
    subprocess.run(["/usr/bin/python3", SCRIPT])
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Done, sleeping {INTERVAL} seconds ...")
    time.sleep(INTERVAL)

