#!/usr/bin/env python3
import time
import subprocess
from datetime import datetime
import os

SCRIPT = "/home/user/app/tests.py"  # 你的脚本路径
RUN_INTERVAL = 1800                 # 30分钟运行一次
KEEP_ALIVE_INTERVAL = 60            # 每分钟保活
LOG_DIR = "/home/user/app/logs"     # 日志目录

# 自动创建日志目录
os.makedirs(LOG_DIR, exist_ok=True)

def log_file():
    return os.path.join(LOG_DIR, datetime.now().strftime("%Y-%m-%d") + ".log")

def write_log(msg):
    try:
        with open(log_file(), "a") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")
    except Exception as e:
        print(f"写日志失败: {e}")

def keep_alive_action():
    write_log("Keep-alive tick")

def run_script():
    write_log(f"Running {SCRIPT} ...")
    try:
        result = subprocess.run(["/usr/bin/python3", SCRIPT], capture_output=True, text=True)
        write_log(result.stdout.strip())
        if result.stderr:
            write_log("ERROR: " + result.stderr.strip())
    except Exception as e:
        write_log(f"运行脚本失败: {e}")
    write_log("Done")

last_run = time.time() - RUN_INTERVAL  # 启动立即运行一次

while True:
    now = time.time()
    if now - last_run >= RUN_INTERVAL:
        run_script()
        last_run = now
    keep_alive_action()
    time.sleep(KEEP_ALIVE_INTERVAL)

